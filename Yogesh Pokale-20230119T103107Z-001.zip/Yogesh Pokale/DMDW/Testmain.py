import numpy as np

arr=np.array([[2,3,4],[3,4,5],[4,5,6]])
print(arr.ndim)
print(arr.shape)
print(arr[:,:,1])